### BBVA Thin2 application

_Thin2_ application skeleton.