const http = require('http');
const static = require('node-static');

const file = new static.Server('./dist');

http.createServer((request, response) => {
    request.addListener('end', function () {
        file.serve(request, response);
    }).resume();
}).listen(8080);