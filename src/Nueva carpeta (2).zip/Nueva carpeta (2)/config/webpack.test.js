'use strict';

const path = require('path');

const AngularCompilerPlugin = require('@ngtools/webpack').AngularCompilerPlugin;
const LoaderOptionsPlugin = require('webpack/lib/LoaderOptionsPlugin');
const webpack = require('webpack');

module.exports = {

    devtool: 'inline-source-map',
    resolve: require('./webpack.resolve'),
    mode: 'development',
    module: {
        rules: [
            {
                enforce: 'pre',
                test: /\.js$/,
                use: 'source-map-loader',
                exclude: [
                    // these packages have problems with their sourcemaps
                    path.resolve('node_modules/rxjs'),
                    path.resolve('node_modules/@angular')
                ]
            },

            {
                test: /\.ts$/,
                use: [
                    {
                        loader: 'awesome-typescript-loader',
                        query: {
                            /**
                             * Use inline sourcemaps for "karma-remap-coverage" reporter
                             */
                            sourceMap: false,
                            inlineSourceMap: true,
                            compilerOptions: {
                                /**
                                 * Remove TypeScript helpers to be injected
                                 * below by DefinePlugin
                                 */
                                removeComments: true
                            }
                        }
                    },
                    'angular2-template-loader'
                ],
                exclude: [/\.e2e\.ts$/]
            },

            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader'],
                include: path.join(__dirname, '..', 'src', 'styles')
            },

            {
                test: /\.scss$/,
                use: ['style-loader', 'css-loader', 'sass-loader'],
                include: path.join(__dirname, '..', 'src', 'styles')
            },

            { test: /\.html$/, use: 'html-loader?minimize=false&' + JSON.stringify({attrs: ['img:src']}) },

            // -------------------------------------------------------------------
            {
                test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
                use: "url-loader?limit=10000&mimetype=application/font-woff&name=fonts/[name].[ext]"
            },

            {
                test: /\.(ttf|eot|svg)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
                use: "url-loader?limit=10000&name=fonts/[name].[ext]"
            },

            {
                test: /\.(jpe?g|png|gif)$/i,
                use: 'file-loader?name=images/[name].[ext]'
            },

            {
                test: /\.(js|ts)$/,
                enforce: 'post',
                use: 'istanbul-instrumenter-loader',
                include: path.join(__dirname, '..', 'src'),
                exclude: [
                    /\.(e2e|spec)\.ts$/,
                    /node_modules/
                ]
            }
        ]
    },

    plugins: [
        //
        // skipCodeGeneration means non-AOT compilation
        new AngularCompilerPlugin({
            tsConfigPath: path.join(__dirname, '..', 'tsconfig.json'),
            entryModule: path.join(__dirname, '..', 'src', 'app', 'app.module#AppModule'),
            skipCodeGeneration: true
        }),

        // fix the warning in ./~/@angular/core/src/linker/system_js_ng_module_factory_loader.js
        new webpack.ContextReplacementPlugin(
            /\@angular(\\|\/)core(\\|\/)esm5/,
            path.resolve('./src')
        ),

        //
        new webpack.ProvidePlugin({
            $: "jquery",
            jQuery: "jquery",
            "window.jQuery": "jquery",
            Popper: "popper.js",
            "window.Popper": "popper.js",
        }),

        new LoaderOptionsPlugin({
            debug: false,
            options: {
                tslint: {
                    emitErrors: false,
                    failOnHint: false,
                    resourcePath: 'src'
                },

            }
        })
    ],
    node: {
        global: true,
        process: false,
        crypto: 'empty',
        module: false,
        clearImmediate: false,
        setImmediate: false
    }
};
