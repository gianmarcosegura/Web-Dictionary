'use strict';

const path = require('path');

const autoprefixer = require('autoprefixer');
const ContextReplacementPlugin = require('webpack/lib/ContextReplacementPlugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const ProgressPlugin = require('webpack/lib/ProgressPlugin');
const ScriptExtHtmlWebpackPlugin = require('script-ext-html-webpack-plugin');
const WebpackInlineManifestPlugin = require('webpack-inline-manifest-plugin');
const webpack = require('webpack');

const entryPoints = ['inline', 'polyfills', 'sw-register', 'styles', 'vendor', 'main'];

module.exports = [
    //
    new webpack.LoaderOptionsPlugin({
        options: {
            context: path.join(__dirname, '..', 'src'),
            output: {
                path: path.join(__dirname, '..', 'dist')
            },
            postcss: [
                autoprefixer
            ]
        }
    }),

    //
    new HtmlWebpackPlugin({
        "template": 'src/index.html',
        "xhtml": true,
        "inject": true,
        "compile": true,
        "chunks": "all",
        "excludeChunks": [],
        "chunksSortMode": function sort(left, right) {
            let leftIndex = entryPoints.indexOf(left.names[0]);
            let rightindex = entryPoints.indexOf(right.names[0]);
            if (leftIndex > rightindex) {
                return 1;
            }
            else if (leftIndex < rightindex) {
                return -1;
            }
            else {
                return 0;
            }
        }
    }),

    //
    new ScriptExtHtmlWebpackPlugin({
        sync: /inline|polyfills/,
        defaultAttribute: 'async',
        preload: [/polyfills|main/],
        prefetch: [/chunk/]
    }),

    //
    new ContextReplacementPlugin(
        /**
         * The (\\|\/) piece accounts for path separators in *nix and Windows
         */
        /\@angular(\\|\/)core(\\|\/)esm5/,
        path.join(__dirname, '..', 'src'),
        {
            /**
             * your Angular Async Route paths relative to this root directory
             */
        }
    ),

    //
    new WebpackInlineManifestPlugin(),

    //
    new webpack.ProvidePlugin({
        $: "jquery",
        jQuery: "jquery",
        "window.jQuery": "jquery",
        Popper: "popper.js",
        "window.Popper": "popper.js",
    }),

    //
    new MiniCssExtractPlugin({ filename: '[name]-[hash].css', chunkFilename: '[name]-[chunkhash].css' }),

    //
    new ProgressPlugin(),

    //
    new CopyWebpackPlugin([
        { from: 'src/mocks/', to: 'mocks/' },  // Mocks
        { from: 'src/thin2', to: '' },  // Config service mock
        { from: 'src/favicon', to: '' }, // Favicon
        { from: 'node_modules/xlsx/dist/xlsx.full.min.js', to: 'scripts/xlsx.min.js' }, // XLSX
        { from: 'node_modules/pdfmake/build/pdfmake.js', to: 'scripts/pdfmake.js' }, // pdfmake
        { from: 'node_modules/pdfmake/build/vfs_fonts.js', to: 'scripts/vfs_fonts.js' }, // vfs_fonts for pdfmake
    ], {
        // By default, we only copy modified files during a watch or webpack-dev-server build.
        // Setting this to `true` copies all files.
        copyUnmodified: false
    })
];
