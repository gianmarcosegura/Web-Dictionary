'use strict';

const path = require('path');

const MiniCssExtractPlugin = require('mini-css-extract-plugin');

module.exports = [
    // -------------------------------------------------------------------
    {
        test: /\.css$/,
        use: [MiniCssExtractPlugin.loader, 'css-loader'],
        include: path.join(__dirname, '..', 'src', 'styles')
    },

    // -------------------------------------------------------------------
    {
        test: /\.scss$/,
        use: [MiniCssExtractPlugin.loader, 'css-loader', 'sass-loader'],
        include: [
            path.join(__dirname, '..', 'src'),
            path.join(__dirname, '..', 'node_modules')
        ]
    },

    // -------------------------------------------------------------------
    {
        test: /\.html$/,
        use: {
            loader: 'html-loader',
            options: {
                minimize: false,
                attrs: ['img:src']
            }
        },
        // If we exclude the index from this loader, HtmlWebpackPlugin manages it and attempts to
        // process Thymeleaf's variable syntax.
        exclude: [
            path.join(__dirname, '..', 'src', 'index.html'),
            path.join(__dirname, '..', 'src', 'relocateIndex.html'),
        ]
    },

    // -------------------------------------------------------------------
    {
        test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        use: {
            loader: "url-loader",
            options: {
                limit: 1000,
                mimetype: 'application/font-woff',
                name: 'fonts/[hash].[ext]'
            }
        }
    },
    {
        test: /\.(ttf|eot|svg)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        use: {
            loader: "url-loader",
            options: {
                limit: 1000,
                name: 'fonts/[hash].[ext]'
            }
        }
    },

    // -------------------------------------------------------------------
    {
        test: /\.(jpe?g|png|gif)$/i,
        use: [
            {
                loader: 'file-loader',
                options: {
                    name: 'images/[hash].[ext]'
                }
            }
        ]
    },
];
