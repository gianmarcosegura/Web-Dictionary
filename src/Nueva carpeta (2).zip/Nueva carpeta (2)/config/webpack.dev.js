'use strict';

const path = require('path');

const webpack = require('webpack');

module.exports = {

    devtool: 'eval-source-map',
    entry: require('./webpack.entry'),
    output: require('./webpack.output'),
    resolve: require('./webpack.resolve'),
    mode: 'development',
    module: {
        rules: require('./webpack.rules').concat([
            // -------------------------------------------------------------------
            {
                test: /\.ts$/,
                use: '@ngtools/webpack',
                exclude: [/\.(spec|e2e)\.ts$/]
            }])
    },
    plugins: require('./webpack.plugins').concat([
        // Fix @angular/core/linker warning
        new webpack.ContextReplacementPlugin(
            /angular(\\|\/)core(\\|\/)(esm(\\|\/)src|src)(\\|\/)linker/,
            path.join(__dirname, '..', 'src')
        ),
        // Fix @angular/core.es5.js warning
        new webpack.ContextReplacementPlugin(
            /angular(\\|\/)core(\\|\/)@angular/,
            path.join(__dirname, '..', 'src')
        )]),
    node: {
        global: true,
        crypto: 'empty',
        process: true,
        module: false,
        clearImmediate: false,
        setImmediate: false
    }
};
