'use strict';

const path = require('path');

const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

module.exports = {
    concatenateModules: true,
    minimizer: [
        new UglifyJsPlugin({
            sourceMap: true,
            parallel: true,
            cache: path.join(__dirname, '..', 'webpack-cache/uglify-cache'),
            uglifyOptions: {
                ecma: 5,
                warnings: false,
                ie8: false,
                mangle: true,
                compress: {
                    pure_getters: true /* buildOptimizer */,
                    // PURE comments work best with 3 passes.
                    // See https://github.com/webpack/webpack/issues/2899#issuecomment-317425926.
                    passes: 2 /* buildOptimizer */
                },
                output: {
                    ascii_only: true,
                    comments: false
                }
            }
        })
    ]
};
