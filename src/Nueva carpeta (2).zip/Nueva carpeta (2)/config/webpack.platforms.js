'use strict';

const CopyWebpackPlugin = require('copy-webpack-plugin');

const translations = require('./../translations');
const copyPath = translations.languages.length > 0 ? '../' : '';

module.exports = {
    devtool: 'source-map',
    entry: require('./webpack.entry.platforms'),
    output: require('./webpack.output'),
    resolve: require('./webpack.resolve'),
    mode: 'production',
    module: {
        rules: require('./webpack.rules').concat([
            // -------------------------------------------------------------------
            {
                test: /\.ts$/,
                use: '@ngtools/webpack'
            }])
    },
    optimization: require('./webpack.optimization'),
    plugins: require('./webpack.plugins').concat([

        //
        new CopyWebpackPlugin([
            {from: 'package.json', to: copyPath},  // Package.json
            {from: 'translations.json', to: copyPath},  // Translations.json
        ]),]),
    node: {
        global: true,
        crypto: 'empty',
        fs: 'empty',
        process: false,
        module: false,
        clearImmediate: false,
        setImmediate: false
    }
};