import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'home-pantalla',
    templateUrl: './home-pantalla.component.html'
})
export class HomePantallaComponent implements OnInit {
    
    @Input() entrada: any;

    optionModificacion: any[] = [];
    
    ngOnInit(): void { 
        console.log(this.entrada)
     }
}
