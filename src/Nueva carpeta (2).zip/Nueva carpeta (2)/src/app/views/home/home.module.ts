import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { HomeComponent } from './home.component';
import { HomePantallaComponent} from './home-pantalla/home-pantalla.component';
import { HomeViewRoutingModule } from './home.routing';
import { Thin2ComponentsProvidersModule } from 'thin2-components';
import { FormsModule } from '@angular/forms';

@NgModule({
    declarations: [
        HomeComponent,
        HomePantallaComponent
    ],
    imports: [
        CommonModule,
        HomeViewRoutingModule,
        Thin2ComponentsProvidersModule,
        FormsModule
    ],
})

export class HomeViewModule {
}
