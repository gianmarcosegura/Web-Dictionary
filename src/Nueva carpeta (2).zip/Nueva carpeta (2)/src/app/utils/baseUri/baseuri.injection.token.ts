import { InjectionToken } from '@angular/core';

export const baseUriInjectionToken: InjectionToken<string> = new InjectionToken<string>('baseURI');
