const fs = require('fs');
const path = require('path');

const testingFolder = path.join(__dirname, 'karma');
// Download chromium in case karma folder exists, local environment is not available or it is running on Jenkins
const hasToBeDownloaded = fs.existsSync(testingFolder) && (!process.env.NOVA_HOME || process.env.NLE_JENKINS);

// Do nothing if the postinstall is executed on a module and doesn't need Chromium
if (hasToBeDownloaded) {
    const Downloader = require('./karma/chromium-downloader');
    const ProgressBar = require('progress');

    const platform = Downloader.currentPlatform();
    const revision = require('./package').chromium_revision;
    const revisionInfo = Downloader.revisionInfo(platform, revision);
    // Do nothing if the revision is already downloaded.
    if (revisionInfo.downloaded) {
        console.log('Chromium has already been downloaded');
        return;
    }

    const allRevisions = Downloader.downloadedRevisions();

    const DOWNLOAD_HOST = process.env.PUPPETEER_DOWNLOAD_HOST || process.env.npm_config_puppeteer_download_host;
    Downloader.downloadRevision(platform, revision, DOWNLOAD_HOST, onProgress)
        .then(onSuccess)
        .catch(onError);

    /**
     * @return {!Promise}
     */
    function onSuccess() {
        console.log('Chromium downloaded to ' + revisionInfo.folderPath);
        // Remove previous chromium revisions.
        const cleanupOldVersions = allRevisions.map(({platform, revision}) => Downloader.removeRevision(platform, revision));
        return Promise.all(cleanupOldVersions);
    }

    /**
     * @param {!Error} error
     */
    function onError(error) {
        console.error(`ERROR: Failed to download Chromium r${revision}!`);
        console.error(error);
        process.exit(1);
    }

    let progressBar = null;

    function onProgress(bytesTotal, delta) {
        if (!progressBar) {
            progressBar = new ProgressBar(`Downloading Chromium r${revision} - ${toMegabytes(bytesTotal)} [:bar] :percent :etas `, {
                complete: '=',
                incomplete: ' ',
                width: 20,
                total: bytesTotal,
            });
        }
        progressBar.tick(delta);
    }

    function toMegabytes(bytes) {
        const mb = bytes / 1024 / 1024;
        return `${Math.round(mb * 10) / 10} Mb`;
    }
} else {
    console.log('No need to download Chromium on a dependency');
}