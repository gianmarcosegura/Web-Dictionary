'use strict';

const path = require('path');
const os = require('os');

let DOWNLOADS_FOLDER = '';
if (process.env.NOVA_HOME && !process.env.NLE_JENKINS) {
    DOWNLOADS_FOLDER = path.join(process.env.NOVA_HOME, 'tools', 'chromium');
} else {
    DOWNLOADS_FOLDER = path.join(__dirname, '..', '.local-chromium');
}

const platform = os.platform();
const revision = require('./../package').chromium_revision;
let currentPlatform = '';
if (platform === 'darwin') {
    currentPlatform = 'mac';
} else if (platform === 'linux') {
    currentPlatform = 'linux';
} else if (platform === 'win32') {
    if (os.arch() === 'x64') {
        currentPlatform = 'win64';
    } else {
        currentPlatform = 'win32';
    }
}
const folderPath = path.join(DOWNLOADS_FOLDER, currentPlatform + '-' + revision);

if (currentPlatform === 'mac') {
    process.env.CHROME_BIN = path.join(folderPath, `chrome-${currentPlatform.replace('win64', 'win32')}`, 'Chromium.app', 'Contents', 'MacOS', 'Chromium');
} else {
    process.env.CHROME_BIN = path.join(folderPath, `chrome-${currentPlatform.replace('win64', 'win32')}`, 'chrome');
}

module.exports = function (config) {
    const webpackConfig = require('./../config/webpack.test.js');
    const configuration = {
        autoWatch: true,

        basePath: '',

        browsers: ['ChromeHeadless'],

        customLaunchers: {
            ChromeHeadless: {
                base: 'Chrome',
                flags: [
                    '--disable-gpu',
                    '--headless',
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--remote-debugging-port=9233',
                ],
            },
        },

        colors: true,

        files: [
            {pattern: './karma-test-shim.js', watched: false}
        ],

        frameworks: ['jasmine'],

        logLevel: config.LOG_DEBUG,

        plugins: [
            'karma-chrome-launcher',
            'karma-coverage',
            'karma-jasmine',
            'karma-remap-coverage',
            'karma-sourcemap-loader',
            'karma-spec-reporter',
            'karma-webpack',
        ],

        port: 9876,

        preprocessors: {
            './karma-test-shim.js': ['coverage', 'webpack', 'sourcemap']
        },

        singleRun: true,

        reporters: ['spec', 'progress', 'coverage', 'remap-coverage'],

        coverageReporter: {
            type: 'in-memory',
        },

        remapCoverageReporter: {
            lcovonly: './coverage/lcov.info',
            html: './coverage/html',
        },

        webpack: webpackConfig,

        /**
         * Webpack please don't spam the console when running in karma!
         */
        webpackMiddleware: {
            /**
             * webpack-dev-middleware configuration
             * i.e.
             */
            logLevel: 'warn',
            /**
             * and use stats to turn off verbose output
             */
            stats: {
                /**
                 * options i.e.
                 */
                chunks: false
            }
        },
    };

    // Apply configuration
    config.set(configuration);
};
