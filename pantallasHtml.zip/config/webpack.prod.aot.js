'use strict';

module.exports = {
    devtool: 'source-map',
    entry: require('./webpack.entry'),
    output: require('./webpack.output'),
    resolve: require('./webpack.resolve'),
    mode: 'production',
    module: {
        rules: require('./webpack.rules').concat([
            // -------------------------------------------------------------------
            {
                test: /\.ts$/,
                use: '@ngtools/webpack',
                exclude: [/\.e2e\.ts$/]
            }])
    },
    optimization: require('./webpack.optimization'),
    plugins: require('./webpack.plugins'),
    node: {
        global: true,
        crypto: 'empty',
        process: true,
        module: false,
        clearImmediate: false,
        setImmediate: false
    }

};
