'use strict';

module.exports = {
    // Entry points for the application
    'polyfills': './src/polyfills.ts',
    'main': './src/main.ts'
};
