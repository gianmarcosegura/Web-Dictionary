'use strict';

const path = require('path');

const generateWebpackCfg = require('./../build/build').generateWebpackCfg;
const translations = require('./../translations');
const webpackCfg = require('./webpack.dev');

// skipCodeGeneration means non-AOT compilation
// FIXME: Using JIT compilation doesn't break the aplication, but nothing is translated since no providers are allocated
const defaultAngularCompilerPluginCfg = {
    tsConfigPath: path.join(__dirname, '..', 'tsconfig-build.json'),
    entryModule: path.join(__dirname, '..', 'src', 'app', 'app.module#AppModule'),
    skipCodeGeneration: true
};

console.log('*********************************');
console.log('*********  LOCAL BUILD  *********');
console.log('*********************************\n');
const LOCAL_CONFIGURATION = generateWebpackCfg(webpackCfg, defaultAngularCompilerPluginCfg, translations.defaultLanguage);

module.exports = LOCAL_CONFIGURATION;