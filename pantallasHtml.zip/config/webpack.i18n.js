'use strict';

const webpack = require('webpack');

module.exports = {
    devtool: 'source-map',
    entry: require('./webpack.entry'),
    output: require('./webpack.output'),
    resolve: require('./webpack.resolve'),
    module: {
        rules: require('./webpack.rules').concat([
            // -------------------------------------------------------------------
            {
                test: /\.ts$/,
                use: '@ngtools/webpack'
            }])
    },
    plugins: require('./webpack.plugins').concat([

        //
        new webpack.DefinePlugin({
            'process.env.NODE_ENV': JSON.stringify('production')
        })
    ]),
    node: {
        global: true,
        crypto: 'empty',
        process: true,
        module: false,
        clearImmediate: false,
        setImmediate: false
    }

};
