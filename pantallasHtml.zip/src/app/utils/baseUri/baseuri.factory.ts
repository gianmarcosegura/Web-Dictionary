/*
 *Generates the application base path according to the entry server
 * @returns {string} application base host
 */
export function baseUriFactory() {
   const protocol: string = window.location.protocol;
   let hostName = window.location.hostname;
   const hostNamelocal = window.location.host;

   hostName = hostName === 'localhost' ? `${hostNamelocal}` : `${hostName}/ENOA`;
   return `${protocol}//${hostName}`;
}
