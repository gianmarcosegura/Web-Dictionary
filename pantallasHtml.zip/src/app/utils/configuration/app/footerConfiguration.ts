export const FOOTER = {
    fixed: false,
    items: [
        {
            title: '',
            type: 'element',
            path: '/out',
            icon: 'fa-google',
            tooltip: 'Google Site',
            disabled: false
        },
        {
            title: '',
            type: 'element',
            path: '/out',
            icon: 'fa-facebook',
            tooltip: 'Facebook',
            disabled: false
        },
        {
            title: '',
            type: 'element',
            path: '/out',
            icon: 'fa-twitter fa-inverse',
            tooltip: 'Twitter',
            disabled: false
        },
        {
            title: '',
            type: 'element',
            path: '/out',
            icon: 'fa-instagram fa-inverse',
            tooltip: 'Instagram',
            disabled: false
        },
        {
            title: '',
            type: 'element',
            resource: '',
            path: '/out',
            icon: 'fa-linkedin fa-inverse',
            tooltip: 'Linkedin',
            disabled: false
        }
    ]
};
