export const HEADER = {
    title: 'Thin2 Application',
    sticky: true,
    togglerPosition: 'right',
    leftItems: [
        {
            title: 'Home',
            type: 'element',
            path: '/home',
            icon: 'fa-home',
            tooltip: 'Home',
            disabled: false
        },
        {
            title: 'About',
            type: 'element',
            path: '/about',
            icon: 'fa-info-circle',
            tooltip: 'About',
            disabled: false
        }
    ],
    rightItems: [
        /*{
            title: '',
            type: 'element',
            path: '/login',
            icon: 'fa-sign-out',
            tooltip: 'Exit',
            disabled: false
        }*/
    ]
};
