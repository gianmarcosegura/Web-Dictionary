import { Component, Input, Output, EventEmitter} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
    selector: 'baja1-component',
    templateUrl: 'baja1.component.html'
})
export class Baja1Component{

    @Output() dataForm: EventEmitter<string> = new EventEmitter();
    @Output() change: EventEmitter<string> = new EventEmitter();
    @Input('sistema') set _sistema(sistema: string){
        // sistema = this.sistemas.indexOf(sistema) > -1 ? sistema : 'rdr';
        //if(this.sistemas.indexOf(sistema) > -1)
            //this.optionsLiquidacion = this.sistemaOptions[sistema];
    };
    sistemas: string[] = ['amiga', 'midas', 'rdr'];
    tipoBaja: string = '';
    isSSIEmpty: boolean = true;
    isContrapartidaEmpty: boolean = true;

    
    baja1= new FormGroup({
        SSIText : new FormControl(''),
        contrapartidaText : new FormControl('')
    });
       

    changeSelect(){
        this.dataForm.emit(this.tipoBaja);
    }
    buttonClicked(event: any ){

    }

    changeSSI(event: string){
        if(!event) {
            this.isSSIEmpty = true;
        }else{
            this.isSSIEmpty = false;
        }
    }
    changeContrapartida(event: string){
        if(!event) {
            this.isContrapartidaEmpty = true;
        }else{
            this.isContrapartidaEmpty = false;
        }
        console.log(event);
    }
}