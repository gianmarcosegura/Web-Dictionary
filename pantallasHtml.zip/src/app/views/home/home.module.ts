import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { HomeComponent } from './home.component';
import { HomeViewRoutingModule } from './home.routing';
import { Thin2ComponentsProvidersModule } from 'thin2-components';
import { FormsModule } from '@angular/forms';
import { AltaComponent } from './alta/alta.component';
import { ModificacionComponent } from './modificacion/modificacion.component';
import { BajaComponent } from './baja/baja.component';
import { Baja1Component } from './baja1/baja1.component';

@NgModule({
    declarations: [
        HomeComponent,
        AltaComponent,
        ModificacionComponent,
        BajaComponent,
        Baja1Component
    ],
    imports: [
        CommonModule,
        HomeViewRoutingModule,
        Thin2ComponentsProvidersModule,
        FormsModule
    ],
})

export class HomeViewModule {
}
