import { Component, Input, Output, EventEmitter} from '@angular/core';

@Component({
    selector: 'alta-component',
    templateUrl: 'alta.component.html'
})
export class AltaComponent{

    @Output() dataForm: EventEmitter<string> = new EventEmitter();
    @Input('sistema') set _sistema(sistema: string){
        // sistema = this.sistemas.indexOf(sistema) > -1 ? sistema : 'rdr';
        if(this.sistemas.indexOf(sistema) > -1)
            this.optionsLiquidacion = this.sistemaOptions[sistema];
    };
    sistemas: string[] = ['amiga', 'midas', 'rdr'];
    tipoLiquidacion: string = '';
    optionsLiquidacion: any[] = [];
    sistemaOptions = {
        rdr: [
            {
                type: 'option',
                value: 'cls',
                label: 'CLS',
                disabled: false
            },{
                type: 'option',
                value: 'target',
                label: 'Target',
                disabled: false
            },{
                type: 'option',
                value: 'eba',
                label: 'EBA',
                disabled: false
            },{
                type: 'option',
                value: 'corresponsal',
                label: 'Corresponsal',
                disabled: false
            },{
                type: 'option',
                value: 'cuenta cero',
                label: 'Cuenta Cero',
                disabled: false
            },{
                type: 'option',
                value: 'cuenta',
                label: 'Cuenta',
                disabled: false
            },{
                type: 'option',
                value: 'stmd',
                label: 'STMD',
                disabled: false
            },
            {
                type: 'option',
                value: 'ficticia',
                label: 'Ficticia',
                disabled: false
            },
        ],
        amiga: [
            {
                type: 'option',
                value: 'corresponsal',
                label: 'Corresponsal',
                disabled: false
            },{
                type: 'option',
                value: 'target',
                label: 'Target',
                disabled: false
            },{
                type: 'option',
                value: 'eba',
                label: 'EBA',
                disabled: false
            },
        ],
        midas: [
            {
                type: 'option',
                value: 'midas1',
                label: 'Midas1',
                disabled: false
            }
        ]
    }

    changeSelect(){
        this.dataForm.emit(this.tipoLiquidacion);
    }
}