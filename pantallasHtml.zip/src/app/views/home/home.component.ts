import { Component} from '@angular/core';

@Component({
    selector: 'home-component',
    templateUrl: 'home.component.html'
})
export class HomeComponent {


    radioConfig = {
        solicitud: {
            disabled: false,
            name: 'radio',
            radioButtonList: [
                {
                    color: 'primary',
                    disabled: false,
                    disableRipple: false,
                    id: 'solicitud1',
                    label: 'Alta SSI',
                    labelPosition: 'after',
                    value: 'alta'
                },{
                    color: 'primary',
                    disabled: false,
                    disableRipple: false,
                    id: 'solicitud2',
                    label: 'Modificación',
                    labelPosition: 'after',
                    value: 'modificacion'
                },{
                    color: 'primary',
                    disabled: false,
                    disableRipple: false,
                    id: 'solicitud3',
                    label: 'Baja SSI',
                    labelPosition: 'after',
                    value: 'baja1'
                },
            ],
            value: ''
        },
        sistema: {
            disabled: false,
            name: 'radio',
            radioButtonList: [
                {
                    color: 'primary',
                    disabled: false,
                    disableRipple: false,
                    id: 'sistema1',
                    label: 'RDR',
                    labelPosition: 'after',
                    value: 'rdr'
                },{
                    color: 'primary',
                    disabled: false,
                    disableRipple: false,
                    id: 'sistema2',
                    label: 'Amiga',
                    labelPosition: 'after',
                    value: 'amiga'
                },{
                    color: 'primary',
                    disabled: false,
                    disableRipple: false,
                    id: 'sistema3',
                    label: 'Midas',
                    labelPosition: 'after',
                    value: 'midas'
                },
            ],
            value: ''
        }
    }
    modelForm: any = {
        solicitud: '',
        sistema: '',
        tipoLiquidacion: ''
    }

    optionsLiquidacion: any[] = [];
    sistemaOptions = {
        rdr: [
            {
                type: 'option',
                value: 'cls',
                label: 'CLS',
                disabled: false
            },{
                type: 'option',
                value: 'target',
                label: 'Target',
                disabled: false
            },{
                type: 'option',
                value: 'eba',
                label: 'EBA',
                disabled: false
            },{
                type: 'option',
                value: 'corresponsal',
                label: 'Corresponsal',
                disabled: false
            },{
                type: 'option',
                value: 'cuenta cero',
                label: 'Cuenta Cero',
                disabled: false
            },{
                type: 'option',
                value: 'cuenta',
                label: 'Cuenta',
                disabled: false
            },{
                type: 'option',
                value: 'stmd',
                label: 'STMD',
                disabled: false
            },
            {
                type: 'option',
                value: 'ficticia',
                label: 'Ficticia',
                disabled: false
            },
        ],
        amiga: [
            {
                type: 'option',
                value: 'corresponsal',
                label: 'Corresponsal',
                disabled: false
            },{
                type: 'option',
                value: 'target',
                label: 'Target',
                disabled: false
            },{
                type: 'option',
                value: 'eba',
                label: 'EBA',
                disabled: false
            },
        ],
        midas: [
            {
                type: 'option',
                value: 'midas1',
                label: 'Midas1',
                disabled: false
            }
        ]
    }

    public changeradio(){
        console.log(this.modelForm.solicitud, this.modelForm.sistema);
        if(this.modelForm.solicitud === 'alta' && this.modelForm.sistema !== ''){
            this.optionsLiquidacion = this.sistemaOptions[this.modelForm.sistema];
        }
    }

    changeSelect(e){
        console.log(e);
    }

    altaComponentData(e: string){
        this.modelForm.tipoLiquidacion = e;
        console.log(e, this.modelForm);
    }

}
