import { Component, Input, Output, EventEmitter} from '@angular/core';

@Component({
    selector: 'baja-component',
    templateUrl: 'baja.component.html'
})
export class BajaComponent{

    @Output() dataForm: EventEmitter<string> = new EventEmitter();
    @Input('sistema') set _sistema(sistema: string){
        // sistema = this.sistemas.indexOf(sistema) > -1 ? sistema : 'rdr';
        //if(this.sistemas.indexOf(sistema) > -1)
            //this.optionsLiquidacion = this.sistemaOptions[sistema];
    };
    sistemas: string[] = ['amiga', 'midas', 'rdr'];
    tipoBaja: string = '';

       

    changeSelect(){
        this.dataForm.emit(this.tipoBaja);
    }
}