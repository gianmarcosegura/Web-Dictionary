import { Component, Input, Output, EventEmitter} from '@angular/core';

@Component({
    selector: 'modificacion-component',
    templateUrl: 'modificacion.component.html'
})
export class ModificacionComponent{

    @Output() dataForm: EventEmitter<string> = new EventEmitter();
    @Input('sistema') set _sistema(sistema: string){
        // sistema = this.sistemas.indexOf(sistema) > -1 ? sistema : 'rdr';
        //if(this.sistemas.indexOf(sistema) > -1)
            //this.optionsLiquidacion = this.sistemaOptions[sistema];
    };
    sistemas: string[] = ['amiga', 'midas', 'rdr'];
    tipoModificacion: string = '';

       

    changeSelect(){
        this.dataForm.emit(this.tipoModificacion);
    }
}